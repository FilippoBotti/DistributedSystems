/**
Here, we had to build a simple client-server interation with rmi objects.
**/
package it.unipr.botti;
