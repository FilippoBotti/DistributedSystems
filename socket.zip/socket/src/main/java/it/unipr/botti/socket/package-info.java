/**
Here, we had to build a simple client-server interation with sockets.
**/
package it.unipr.botti.socket;
