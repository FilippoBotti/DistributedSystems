package it.unipr.botti.socket;

public enum MessageType {
    SERVER_PRICE,
    CLIENT_PRICE,
    CLIENT_PASS,
    SERVER_RESPONSE,
    CLIENT_FULL_ITEMS
}
